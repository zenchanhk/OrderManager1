﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmiBroker.Controllers
{
    interface IContract
    {
        int MyProperty { get; set; }
    }
}
